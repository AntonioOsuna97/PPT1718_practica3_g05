/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Random;



/**
 * Clase de atención de un servidor TCP sencillo
 * Prácticas de Protocolos de Transporte
 * Grado en Ingeniería Telemática
 * Universidad de Jaén
 * 
 * NOTA:
 * 
 * @author Juan Carlos Cuevas Martínez, Antonio Osuna y Fernando Cabrera
 */
public class HttpSocketConnection implements Runnable {
    
    public static final String HTTP_Ok="200";
    public static final String HTTP_Bad_Request="400";
    public static final String HTTP_Not_Found="404";
    public static final String HTTP_Method_Not_Allowed="405";
    public static final String HTTP_Version_Not_Supported="505";
    
    
    private Socket mSocket=null;
    
    /**
     * Se recibe el socket conectado con el cliente
     * @param s Socket conectado con el cliente
     */
    public HttpSocketConnection(Socket s){
        mSocket = s;
    }
    
    public void run() {
        //Variables
        String request_line="";
        BufferedReader input;
        DataOutputStream output;
        String contentType="";
        String contentLength="";
        String connection="";
        try {
            byte[] outdata=null;
            byte[] outdataRecurso=null;
            String outmesg="";
            input = new BufferedReader(new InputStreamReader(mSocket.getInputStream()));
            output = new DataOutputStream(mSocket.getOutputStream());
            do{
               
                request_line= input.readLine();
                
                String parts[]=request_line.split(" ");
                //***Preguntar como realizar cabecera connection
                if(request_line.startsWith("Connection: ")){
                    request_line="Connection: close";
                }
                if(request_line.startsWith("GET ")){
                    String resourceFile="";
               
                    
                    if(parts.length==3){
                        //COmprobar la versión
                        String[] respuesta;
                        respuesta=parts[2].split("/");
                        
                        //Juan Carlos: Si es 1 o 1.1 es valido
                        if(respuesta[1].equals("1") || respuesta[1].equals("1.1")){
                            
                        if(!parts[0].equals("GET ")){
                            //*******************Preguntar a Juan Carlos cómo sería la salida de nuestro mensaje
                            //Si sería necesario introducir las cabeceras o no.
                             //outmesg="HTTP/1.1 405\r\nContent-type: text/html\r\n\r\n<html><body><h1>Método no permitido</h1></body></html>";
                            outmesg="HTTP/1.1 405\r\n\r\n<html><body><h1>Método no permitido</h1></body></html>";
                       outdata=outmesg.getBytes(); 
                        }
                        //equalsIgnoreCase compara la cadena con el objeto ignorando mayúsculas y minúsculas
                        if(parts[1].equalsIgnoreCase("/")){
                            resourceFile="index.html";
                        }else
                            //parts[1] --> contiene el tipo de contenido
                            resourceFile=parts[1];
                        //Content-type
                        //Para ello, necesitamos separar parts1 y obtener el tipo de contenido.
                        //Como el tipo de contenido presenta un punto, separaremos por ahí
                        String[] separacionContentType;
                        //Para poder separar con punto necesitamos poner una barra \\. Ya que el punto en split significa
                        //cualquier caracter
                        separacionContentType= parts[1].split("\\.");
                        if(separacionContentType[1].equals("jpg")){
                            contentType="Content-type: image/jpeg";
                        }else if(separacionContentType[1].equals("txt")){
                            contentType="Content-type: text/plain";
                        }else{
                            //Como solo podremos disponibles 3, elegimos que si no es una imagen o texto plano, sea:
                            contentType="Content-type: text/html";
                        }
                            
                        
                        
                          //Hemos tenido que ccrear una nueva variable porque nos sobreescribía outdata
                        outdataRecurso=leerRecurso(resourceFile);
                        //Cabecera content-length  -->El tamaño del contenido de la petición en bytes
                        //Para esta cabecera deberemos obtener el valor en bytes de nuestro outdataRecurso, para ello utilizaremos length
                        contentLength="Content-Length: "+ outdataRecurso.length;
                        
                        if(outdata==null)    {
                            outmesg="HTTP/1.1 404\r\n\r\n<html><body><h1>No encontrado</h1></body></html>";
                            outdata=outmesg.getBytes();    
                        }else{
                            //200 OK
                            //Mensaje con las cabeceras
                            outmesg="HTTP/1.1 200\r\n"+contentType+"\r\n"+contentLength+"\r\n\r\n";
                            outdata=outmesg.getBytes();
                        }
                   // }
                    
                   
                    }else{
                        outmesg="HTTP/1.1 505\r\n\r\n<html><body><h1>HTTP Version Not Supported</h1></body></html>";
                        outdata=outmesg.getBytes();
                        }
                    }else{
                      outmesg="HTTP/1.1 400\r\nContent-type:text/html\r\n\r\n<html><body><h1>Problema en el cliente</h1></body></html>";
                      outdata=outmesg.getBytes();
                    }
            }
                    
                
                
                //Escribe host...
                System.out.println(request_line);
            }while(request_line.compareTo("")!=0);
            //CABECERAS...
            System.out.println("Response HEADER:");   
            String cabeceraContentLength=contentLength;
            //Escribimos en la ventana que nos muestra netbeans la cabecera content-Lenght
            System.out.println(cabeceraContentLength);
            String cabeceraContentType= contentType;
            //Escribimos la cabecera content-Type
            System.out.println(cabeceraContentType);
            
            /* NO VALE
            //Connection controla si la conexión de red permanece abierta
            //después de que finaliza la transacción actual. Si el valor enviado es keep-alive, 
            //la conexión es persistente y no se cierra, lo que permite realizar solicitudes posteriores al mismo servidor.
            //Como la practica nos dice que debe informar de que no admita conexiones persistente, asignamos a cerrado.
            String connection= "Connection: close\r\n";
            //Escribimos la cabecera connection
            System.out.println(connection);
            */
            
            
            //Recurso
           //output.write necesita bytes [escribe byte]
           output.write(outdata);
           output.write(outdataRecurso);
            input.close();
            output.close();
            mSocket.close();
    
        } catch (IOException e) {
            System.err.println("Exception" + e.getMessage());
        }
        }

    /**
     * Método para leer un recurso del disco
     * @param resourceFile
     * @return los bytes del archivo o null si éste no existe
     */
    
    
    
    private byte[] leerRecurso(String resourceFile){
        //Se debe comprobar que existe
        
        //./ es para el directorio
        File f= new File("./"+resourceFile);
        byte[] bytesArray = null;
        try{
       FileInputStream fis = new FileInputStream (f);
       bytesArray = new byte[(int) f.length()];
       fis.read(bytesArray);
       BufferedInputStream bis = new BufferedInputStream(fis);
       bis.read(bytesArray, 0 , bytesArray.length);

        }catch(IOException e) {
            e.printStackTrace();
        }  
       return bytesArray;
    }
    
    
    
}